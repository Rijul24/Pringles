



-------------------------------------------------------DISCLAIMER-------------------------------------------

The story, all names, characters, and incidents portrayed in this production are fictitious.
No identification with actual persons (living or deceased), places, buildings, and products is intended or should be inferred.


This software is the property of Rijul Singla aka SaladCrunch Productions.
Distribution of this software under false identity/without appropriate credit is prohibited.
All and any proceeds made through this game wil go diretly to Rijul Singla.

For any enquiry/issues, reach out to any of my socials or mail at roypotter45@gmail.com
